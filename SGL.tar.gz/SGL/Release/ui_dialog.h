/********************************************************************************
** Form generated from reading UI file 'dialog.ui'
**
** Created by: Qt User Interface Compiler version 4.8.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_H
#define UI_DIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QLabel *label_showpic;
    QLabel *label_dirlist;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QString::fromUtf8("Dialog"));
        Dialog->resize(1280, 720);
        label_showpic = new QLabel(Dialog);
        label_showpic->setObjectName(QString::fromUtf8("label_showpic"));
        label_showpic->setGeometry(QRect(10, 450, 220, 200));
        label_showpic->setFrameShape(QFrame::Box);
        label_showpic->setLineWidth(2);
        label_dirlist = new QLabel(Dialog);
        label_dirlist->setObjectName(QString::fromUtf8("label_dirlist"));
        label_dirlist->setGeometry(QRect(280, 72, 736, 576));
        label_dirlist->setFrameShape(QFrame::Box);
        label_dirlist->setLineWidth(1);

        retranslateUi(Dialog);

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QApplication::translate("Dialog", "Dialog", 0, QApplication::UnicodeUTF8));
        label_showpic->setText(QString());
        label_dirlist->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_H
