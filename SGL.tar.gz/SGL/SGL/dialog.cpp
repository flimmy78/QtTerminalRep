#include "dialog.h"
#include "ui_dialog.h"
#include <dirent.h>
#include <time.h>
#include <stdio.h>
#include <dirent.h>
#include <sys/vfs.h>
#include <QTextCodec>
#include <QPainter>
#include <QMessageBox>


//#include "12.h"   //3d test data

extern"C"
{
int api_sgl(unsigned char* indata,
            unsigned char* outbuffer,
            unsigned int datalen,
            unsigned int width,
            unsigned int height
            );

void draw_event( unsigned char* indata, unsigned int datalen);
void redraw(void *indata, unsigned int datalen);
}

void Dialog::FilePageDown()
{
    int row;
    QKeyEvent key(QEvent::KeyPress, Qt::Key_PageDown, Qt::NoModifier);
    QApplication::sendEvent(fileview->ListWidgetFile, &key);
    row = fileview->ListWidgetFile->currentRow();
    fileview->currentrow = row;
    printf("current row = %d\r\n", row);
}

void Dialog::FilePageUp()
{
    int row;
    QKeyEvent key(QEvent::KeyPress, Qt::Key_PageUp, Qt::NoModifier);
    QApplication::sendEvent(fileview->ListWidgetFile, &key);
    row = fileview->ListWidgetFile->currentRow();
    fileview->currentrow =row;
    printf("current row = %d\r\n", row);
}

int Dialog::SetGPIO(int value)  //write GPIO22
{
    fd_gpio = open_gpio("/dev/dm368_gpio");
    if (fd_gpio < 0)
    {
         printf("Can't open device /dev/dm368_gpio\r\n");
    }
    else
    {
//      printf("Open device /dev/dm368_gpio OK!\r\n");
        gpiobuf[0] = value;
        write(fd_gpio, gpiobuf, 2);
    }
    close_gpio(fd_gpio);
    return 0;
}

void Dialog::SET_AUDIO_BYPASS()
{
    SetGPIO(0);
}
void Dialog::SET_AUDIO_368OUT()
{
    SetGPIO(1);
}


/*
int Dialog::GetGPIO33(void)
{
    fd_gpio = open_gpio("/dev/dm368_gpio");
    if (fd_gpio < 0)
    {
         printf("Can't open device /dev/dm368_gpio\r\n");
    }
    else
    {
        read(fd_gpio, gpiobuf, 2);
    }
    close_gpio(fd_gpio);
    if(0 ==gpiobuf[2])
      return 0;
    else
      return 1;
}
*/

unsigned int CheckoutDiskSpace(unsigned int* totalspace)
{
    struct statfs diskInfo;
    unsigned long long totalBlocks;
    unsigned long long totalSize;
    size_t mbTotalsize;
    unsigned long long freeDisk;
    size_t mbFreedisk;

    statfs("/home/root/media/", &diskInfo);
    totalBlocks = diskInfo.f_bsize;
    totalSize = totalBlocks*diskInfo.f_blocks;
    mbTotalsize = totalSize >> 20;//compute the size by unit MB, 20 = 1MB

    *totalspace = mbTotalsize;

    freeDisk = diskInfo.f_bfree*totalBlocks;
    mbFreedisk = freeDisk >> 20;
//	printf("/dev/sda1 total = %dMB, free = %dMB\n", mbTotalsize, mbFreedisk);
    return mbFreedisk;
}


unsigned char DetectTFCard(void)
{
    unsigned char cardexist = 0;

    if(fopen("/dev/mmcblk0p1", "r") == NULL)
    {
        printf("No TF Card Insert!\r\n");
        cardexist = 0;
    }
    else
    {
        system("mount -t vfat /dev/mmcblk0p1 /home/root/media/");
        system("insmod /dm368/g_file_storage.ko file=/dev/mmcblk0p1 stall=0 removable=1");
        printf("Mount TF Card OK!  (/dev/mmcblk0p1)\r\n");
        cardexist = 1;
        return cardexist;
    }

    if(0 == cardexist)
    {
        if(fopen("/dev/mmcblk0", "r") == NULL)
        {
            printf("No TF Card Insert!\r\n");
            cardexist = 0;
        }
        else
        {
            system("mount -t vfat /dev/mmcblk0 /home/root/media/");
            system("insmod /dm368/g_file_storage.ko file=/dev/mmcblk0 stall=0 removable=1");
            printf("Mount TF Card OK!  (/dev/mmcblk0)\r\n");
            cardexist = 1;
        }
    }
    return cardexist;
}


int RunUpdateFirmware()
{
    unsigned char update_status = 0;

    if( access("/home/root/media/SGL", R_OK) == 0)  //test SGL file
    {
        system("cp /home/root/media/SGL /dm368/");
        system("rm /home/root/media/SGL");
        printf("Update <SGL> File!\r\n");
        update_status ++;
    }
    else
    {
        printf("No <SGL> File!\r\n");
    }

    if( access("/home/root/media/encode", R_OK) == 0)  //test encode file
    {
        printf("Uptate <encode> File!\r\n");
        system("cp /home/root/media/encode /dm368/");
        system("rm /home/root/media/encode");
        update_status ++;
    }
    else
    {
        printf("No <encode> File!\r\n");
    }

    if( access("/home/root/media/decode", R_OK) == 0)  //test decode file
    {
        printf("Update <decode> File!\r\n");
        system("cp /home/root/media/decode /dm368/");
        system("rm /home/root/media/decode");
        update_status ++;
    }
    else
    {
        printf("No <decode> File!\r\n");
    }
    return update_status;
}


void Dialog::senduartcmd(unsigned char retcmdtype)
{
    const char returncmd[20][RETCMDLEN] = {
        {0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA},  //00  NO USE
        {0xAA, 0x05, 0x03, 0x3D, 0x00, 0x01, 0xCC, 0xEB, 0xAA},  //01  system start ok
        {0xAA, 0x05, 0x03, 0x3D, 0x00, 0x02, 0xCC, 0xEB, 0xAA},  //02  close file browse
        {0xAA, 0x05, 0x03, 0x3D, 0x00, 0x03, 0xCC, 0xEB, 0xAA},  //03  get time
        {0xAA, 0x05, 0x03, 0x3D, 0x00, 0x04, 0xCC, 0xEB, 0xAA},  //04  enter low power mode
        {0xAA, 0x05, 0x03, 0x3D, 0x00, 0x05, 0xCC, 0xEB, 0xAA},  //05  ready for reset
        {0xAA, 0x05, 0x03, 0x3D, 0x00, 0x06, 0xCC, 0xEB, 0xAA},  //06  tf card cap low
        {0xAA, 0x05, 0x03, 0x3D, 0x00, 0x07, 0xCC, 0xEB, 0xAA},  //07  tf card cap full
        {0xAA, 0x05, 0x03, 0x3D, 0x00, 0x08, 0xCC, 0xEB, 0xAA},  //08  exit low power mode
        {0xAA, 0x05, 0x03, 0x3D, 0x00, 0x09, 0xCC, 0xEB, 0xAA},  //09  tf card cap ok
        {0xAA, 0x05, 0x03, 0x3D, 0x00, 0x0A, 0xCC, 0xEB, 0xAA},  //0a  start update firmware
        {0xAA, 0x05, 0x03, 0x3D, 0x00, 0x0B, 0xCC, 0xEB, 0xAA},  //0b  update firmware ok
        {0xAA, 0x05, 0x03, 0x3D, 0x00, 0x0C, 0xCC, 0xEB, 0xAA},  //0c  tf card ok

        {0xAA, 0x05, 0x03, 0xFF, 0x00, 0x00, 0xCC, 0x31, 0x01},  //0d  ret photo
        {0xAA, 0x05, 0x03, 0xFF, 0x00, 0x00, 0xCC, 0x32, 0x01},  //0e  ret record
        {0xAA, 0x05, 0x03, 0xFF, 0x00, 0x00, 0xCC, 0x33, 0x01},  //0f  ret stop record
        {0xAA, 0x05, 0x03, 0xFF, 0x00, 0x00, 0xCC, 0x34, 0x01},  //10  ret triggle photo
        {0xAA, 0x05, 0x03, 0xFF, 0x00, 0x00, 0xCC, 0x35, 0x01},  //11  ret opendir
    };
    switch(retcmdtype)
    {
    case RET_START_OK:
        write(fd_com, returncmd[0x01], RETCMDLEN);
        break;
    case RET_CLOSE_DIR:
        write(fd_com, returncmd[0x02], RETCMDLEN);
        break;
    case RET_GET_TIME:
        write(fd_com, returncmd[0x03], RETCMDLEN);
        break;
    case RET_LOWPW_MODE:
        write(fd_com, returncmd[0x04], RETCMDLEN);
        break;
    case RET_READY_RESET:
        write(fd_com, returncmd[0x05], RETCMDLEN);
        break;
    case RET_TFCAP_LOW:
        write(fd_com, returncmd[0x06], RETCMDLEN);
        break;
    case RET_TFCAP_FULL:
        write(fd_com, returncmd[0x07], RETCMDLEN);
        break;
    case RET_NORMAL_MODE:
        write(fd_com, returncmd[0x08], RETCMDLEN);
        break;
    case RET_TFCAP_OK:
        write(fd_com, returncmd[0x09], RETCMDLEN);
        break;
    case RET_START_UPDATE:
        write(fd_com, returncmd[0x0a], RETCMDLEN);
        break;
    case RET_STOP_UPDATE:
        write(fd_com, returncmd[0x0b], RETCMDLEN);
        break;
    case RET_FORMAT_SD:
        write(fd_com, returncmd[0x0c], RETCMDLEN);
        break;

    case RET_CMD_PHOTO:
        write(fd_com, returncmd[0x0d], RETCMDLEN);
        break;
    case RET_CMD_STARTREC:
        write(fd_com, returncmd[0x0e], RETCMDLEN);
        break;
    case RET_CMD_STOPREC:
        write(fd_com, returncmd[0x0f], RETCMDLEN);
        break;
    case RET_CMD_TRIGPIC:
        write(fd_com, returncmd[0x10], RETCMDLEN);
        break;
    case RET_CMD_OPENDIR:
        write(fd_com, returncmd[0x11], RETCMDLEN);
        break;
    }
}


Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    msgServer.start(QThread::HighPriority);
    ui->setupUi(this);

    ////////can used as display D1 video///////////////////////////////////
    ui->label_dirlist->setFrameShape (QFrame::Box);
    ui->label_dirlist->setStyleSheet("border: 1px solid  #0000ff");
    ui->label_dirlist->setStyleSheet("background-color: rgb(0, 0, 255);");
    ui->label_dirlist->setGeometry(280, 72, 720, 576);
    ui->label_dirlist->show();


    ////////can used as display 3D module///////////////////////////////////
    width_3d  = WIDTH_3DBOX;
    height_3d = HEIGHT_3DBOX;
    bytePerLine_3d = WIDTH_3DBOX*2;

 //   m_ScanDataLen = sizeof(TestData); ///////use test data
 //   memcpy(m_ScanData, TestData,  m_ScanDataLen);

    api_sgl(m_ScanData, framedata, m_ScanDataLen, width_3d, height_3d);
    image_draw3d = new QImage(framedata, width_3d, height_3d, bytePerLine_3d, QImage::Format_RGB555);

    ui->label_showpic->setFrameShape (QFrame::Box);
    ui->label_showpic->setStyleSheet("border: 1px solid  #0000ff");
    ui->label_showpic->setStyleSheet("background-color: rgb(0, 0, 255);");
    ui->label_showpic->setGeometry(10, 450,width_3d, height_3d);
    ui->label_showpic->show();
    ui->label_showpic->setPixmap(QPixmap::fromImage(*image_draw3d));
    ui->label_showpic->show();

    delete image_draw3d;


    /*
    fd_watchdog = open_watchdog();
    if(fd_watchdog == -1)
    {
        printf("FAILED to open /dev/watchdog\r\n");
    }
    else
    {
        printf("Successful to open /dev/watchdog\r\n");
    }
    */

 //   int update = 0;

    gl_TFcardExist = 0;
    gl_TFcardExist = DetectTFCard();
    gl_TFcapalarm = 0;


    fileview = new FileViewer(this);


    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(command_timerUpDate()) );
    timer->start(20);

//    timerflush = new QTimer(this);
//    connect(timerflush, SIGNAL(timeout()), this, SLOT(FlushUpDate()) );
//    timerflush->start(2000);

    recvthread = new ReceiveThread;
    recvthread->fileview   = fileview;

    /////////serial open//////////////////////////////////////////////////////
    fd_com = check_port_open("/dev/ttyS1", 115200);
    clear_send(fd_com);

    systemstatus = STATUS_IDEL;

    system("./encodertsp -v 1.264 -a 1.aac -y 2 -I 1 &");
    SET_AUDIO_BYPASS();
}


void get_extension(const char *file_name, char *extension)
{
    int i=0,length;
    length=strlen(file_name);

    while(file_name[i])
    {
        if(file_name[i]=='.')
            break;
        i++;
    }
    if(i<length)
        strcpy(extension, file_name+i+1);
    else
        strcpy(extension,"\0");
}


void Dialog::close_browser()
{
    fileview->close();
    ui->label_dirlist->setStyleSheet("background-color: rgb(0, 0, 0);");
    ui->label_dirlist->clear();//setPixmap(QPixmap::fromImage(image.scaled(LISBOX_WIDTH, LISBOX_HEIGHT)));
}

void Dialog::open_browser()
{
    ui->label_dirlist->setStyleSheet("background-color: rgb(0, 0, 255);");
    fileview->setParent(ui->label_dirlist);
    fileview->setGeometry(0, 0, LISBOX_WIDTH, LISBOX_HEIGHT);
    fileview->showFileInfoList();
    if(fileview->filenumber > 0)
    {
        fileview->ListWidgetFile->setCurrentRow(fileview->currentrow);
    }
    fileview->show();

}


int Dialog::prepare_play(unsigned char mode)
{
    int status = 0xff;
    char fext[3];
    char strtime[20] = {0};
    struct tm *p_tm;

    memset(cmdbuf, 0, 128);

    QString str = fileview->ListWidgetFile->currentItem()->text();
    QByteArray ba = str.toLatin1();
    char *mm =   ba.data();
    char *file = ba.data();

    get_extension(mm, fext);

    sprintf(cmdbuf, "/home/root/media/%s", file);
    /////////////show file information////////
    stat(cmdbuf, &gl_filestat);  //get file path and name
    p_tm = localtime(&gl_filestat.st_mtime);
    strftime(strtime, sizeof(strtime), "%Y-%m-%d %H:%M:%S", p_tm);
    str.sprintf("文件日期: %s", strtime);
 //   ui->label_1->setText(str);
    str.sprintf("文件类型: %s", fext);
 //   ui->label_2->setText(str);
    str.sprintf("文件大小: %dK", (int)(gl_filestat.st_size/1024) );
 //   ui->label_3->setText(str);

    printf("select file:%s\r\n", file);

    if(0 == strcmp(fext, "bmp"))  ///show bmp in label
    {
        gl_filetype = FILE_IS_BMP;

        if( !image.load(cmdbuf) )
        {
            printf("Load Bmp failed!\r\n");
            return status;
        }
        ui->label_dirlist->setPixmap(QPixmap::fromImage(image.scaled(LISBOX_WIDTH, LISBOX_HEIGHT)));
 //       ui->label_dirlist->raise();
    }

    else if(0 == strcmp(fext, "avi"))
    {
        gl_filetype = FILE_IS_AVI;

        sprintf(cmdbuf, "./decode -y 2 -v h264 -f /home/root/media/%s", file);
        memcpy(recvthread->commandbuffer, cmdbuf, 128);
        recvthread->status = STATUS_PLAY;
        recvthread->start();

        SET_AUDIO_368OUT(); //368 out
    }
    status = gl_filetype;
    return status;
}

void Dialog::FlushUpDate()
{
    QString str;
    int leftpercent;

    if(1 == gl_TFcardExist)   //tf card exist
    {
        gl_TFleft = CheckoutDiskSpace(&gl_TFtotal);

        leftpercent = 100*gl_TFleft/gl_TFtotal;

        str.sprintf("存储空间总共:%dMB", gl_TFtotal);
        //ui->label_4->setText(str);

        str.sprintf("存储空间使用:%dMB", gl_TFtotal-gl_TFleft);
        //ui->label_5->setText(str);

        str.sprintf("存储空间剩余:%dMB", gl_TFleft);
        //ui->label_6->setText(str);

        if(leftpercent < 5)
        {
            gl_TFcapalarm = 1;
            senduartcmd(RET_TFCAP_LOW);     //return:tf card cap low
        }
        else if(leftpercent < 1)
        {
            gl_TFcapalarm = 1;
            senduartcmd(RET_TFCAP_FULL);    //return:tf card cap full
        }
        else
        {
            senduartcmd(RET_TFCAP_OK);      //return:tf card cap ok
        }
    }
}


int Dialog::SkipDownFile()
{
    char fext[3];
    while(fileview->currentrow < fileview->filenumber-1)
    {
        fileview->nextrow();
        QString str = fileview->ListWidgetFile->currentItem()->text();
        QByteArray ba = str.toLatin1();
        char *mm =   ba.data();
        char *file = ba.data();
        get_extension(mm, fext);
        printf("current file: %s, ext: %s\r\n", file, fext);
        if(0 == strcmp(fext, "BMP"))  //show bmp in label
        {
            gl_filetype = FILE_IS_BMP;
            fileview->lastvalidrow = fileview->currentrow; //store last valid row
            return 0;
        }
    }
    return 0xff;
}

int Dialog::SkipUpFile()
{
    char fext[3];

    while( fileview->currentrow > 0 )
    {
        fileview->prevrow();

        QString str = fileview->ListWidgetFile->currentItem()->text();
        QByteArray ba = str.toLatin1();
        char *mm =   ba.data();
        char *file = ba.data();

        get_extension(mm, fext);
        printf("current file: %s, ext: %s\r\n", file, fext);

        if(0 == strcmp(fext, "BMP"))  //show bmp in label
        {
            gl_filetype = FILE_IS_BMP;
            fileview->lastvalidrow = fileview->currentrow; //store last valid row
            return 0;
        }
    }
    return 0xff;
}

int checksum()
{
    return 0;
}


unsigned int Dialog::getuartcmd(unsigned char* cmdbuf)
{
    int ret;
    int cmdtype;

    ret = read(fd_com, cmdbuf, 32);  //get 32 bytes from serial port

    if(cmdbuf[0] == 0xAA)  //start code
    {
        if( (cmdbuf[1] == 0x05)||(cmdbuf[1] == 11) ) //command length=5 or 11
        {
            if((cmdbuf[7] == 0xEB) && (cmdbuf[8] == 0xAA) ) //short command, end code
            {
                cmdtype = cmdbuf[3];
                cmdtype <<= 8;
                cmdtype |= cmdbuf[5];
                printf("QT serial get cmd =%04X\r\n", cmdtype);
                return cmdtype;
            }
            else if((cmdbuf[13] == 0xEB) && (cmdbuf[14] == 0xAA) ) //long command, end code
            {

            }
        }
    }
    return 0xffff;
}

void Dialog::command_timerUpDate()
{
    unsigned char commandbuf[16]={0};
 //   int cmdlength;
    int systemcommand;

    //feed the watchdog
    /*
    if(fd_watchdog >= 0)
    {
        static unsigned char food = 0;
        ssize_t eaten = write(fd_watchdog, &food, 1);
        if(eaten != 1)
        {
            printf("FAILED feeding watchdog\r\n");
        }
    }
    */

    systemcommand = getuartcmd(commandbuf);      //get serial command

    if(systemcommand == CMD_3D_CHANGE) //change 3d angle
    {
        draw_event(m_ScanData, m_ScanDataLen);
        image_draw3d = new QImage(framedata, width_3d, height_3d, bytePerLine_3d, QImage::Format_RGB555);
        ui->label_showpic->setPixmap(QPixmap::fromImage(*image_draw3d));
        ui->label_showpic->show();
        delete image_draw3d;
    }


    else if(systemcommand == CMD_SETTIME)          //set system time
    {
        gl_year   = commandbuf[5];
        gl_month  = commandbuf[6];
        gl_date   = commandbuf[7];
        gl_hour   = commandbuf[8];
        gl_minute = commandbuf[9];
        gl_second = commandbuf[10];

        write(fd_com, commandbuf, LONG_CMDLEN);
    }


    if(systemstatus == STATUS_IDEL)   //current mode: encode preview
    {
        switch(systemcommand)
        {
        case CMD_GET_PIC:  //get a picture while preview
        case CMD_TRIG_PIC:
            if(gl_TFcardExist)
            {
                printf("Current:idel   Operation:get bmp file\r\n");
                msgServer.sendCmd(QtInterface_Photo);
            }
            break;

        case CMD_OPEN_DIR:
            printf("Current:idel   Operation:exit encode preview\r\n");
            system("pkill -9 encodertsp");
            systemstatus = STATUS_DIRLIST;  //enter dir list status
            open_browser();
            SET_AUDIO_BYPASS();
            break;

        case CMD_START_REC:
            if(gl_TFcardExist)
            {
                printf("Current:idel   Operation:start record\r\n");
                msgServer.sendCmd(QtInterface_Record);
                systemstatus = STATUS_ENCODE;
            }
            break;
        }
    }
    else if(systemstatus == STATUS_ENCODE)  //current mode:encode save file
    {
        switch(systemcommand)
        {
        case CMD_STOP_REC:  //stop encode
            systemstatus = STATUS_IDEL;
            msgServer.sendCmd(QtInterface_Stop);
            system("sync");
            break;

        case CMD_TRIG_PIC:  //triggle a picture when encoding
        case CMD_GET_PIC:
            if(gl_TFcardExist)
            {
                msgServer.sendCmd(QtInterface_Photo);
            }
            break;
        }
    }
    else if(systemstatus == STATUS_DIRLIST)   // dir list status
    {
        switch(systemcommand)
        {
        case CMD_KEY_UP: //key up
            fileview->prevrow();
            break;

        case CMD_KEY_DOWN: //key down
            fileview->nextrow();
            break;

        case CMD_KEY_ENTER:  //key enter
            if(fileview->filenumber > 0)
            {
                printf("start play\r\n");
                close_browser();
                prepare_play(1);
                systemstatus = STATUS_PLAY;
            }
            break;

        case CMD_CLOSE_DIR:
        case CMD_KEY_EXIT:   //key exit
            systemstatus = STATUS_IDEL;      //exit dir list status
            close_browser();
            system("./encodertsp -v 1.264 -a 1.aac -y 2 -I 1 &");
            SET_AUDIO_BYPASS();
            break;
        }
    }   
    else if( systemstatus == STATUS_PLAY )  //full screen play and show mode
    {
        if(recvthread->status == STATUS_PLAYEND) //play avi end
        {
            recvthread->status = STATUS_IDEL;
            open_browser();
            systemstatus = STATUS_DIRLIST;  //exit dir list status
            SET_AUDIO_BYPASS();
        }

        switch(systemcommand)
        {
        case CMD_KEY_ENTER:  //in pause mode
            if(FILE_IS_AVI == gl_filetype) //playing the avi file
            {
                printf("send fifo pause command\r\n");
                msgServer.sendCmd(QtInterface_Pause);
                systemstatus = STATUS_PAUSE;
            }
            else if(FILE_IS_BMP == gl_filetype)
            {
                systemstatus = STATUS_DIRLIST;  //exit dir list status
                open_browser();
                printf("======return to dirlist mode\r\n");
            }
            break;

        case CMD_KEY_EXIT:
            if(FILE_IS_AVI == gl_filetype) //playing the avi file
            {
                system("pkill -9 decode");
                recvthread->status = STATUS_IDEL;
                systemstatus = STATUS_DIRLIST;  //exit dir list status
                open_browser();
                SET_AUDIO_BYPASS();
                printf("======return to dirlist mode\r\n");
            }
            else if(FILE_IS_BMP == gl_filetype)
            {
                systemstatus = STATUS_DIRLIST;  //exit dir list status
                open_browser();
                printf("======return to dirlist mode\r\n");
            }
            break;
        }
    }
    else if(systemstatus == STATUS_PAUSE)//now in pause, play it
    {
        switch(systemcommand)
        {
        case CMD_KEY_ENTER:  //in pause mode, enter command
            if(FILE_IS_AVI == gl_filetype) //playing the avi file
            {
                msgServer.sendCmd(QtInterface_Play);
                systemstatus = STATUS_PLAY;
            }
            break;
        case CMD_KEY_EXIT:
            if(FILE_IS_AVI == gl_filetype) //playing the avi file
            {
                system("pkill -9 decode");
                recvthread->status = STATUS_IDEL;
                systemstatus = STATUS_DIRLIST;  //exit dir list status
                open_browser();
                SET_AUDIO_BYPASS();
                printf("======return to dirlist mode\r\n");
            }
            break;
        }
    }
}


Dialog::~Dialog()
{
    delete ui;
}
