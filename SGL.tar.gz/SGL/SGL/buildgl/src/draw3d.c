#define _FB_TK_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <GL/gl.h>
#include "picotk.h"
#include <math.h>
#include <GL/internal/zgl.h>
#include "glx_impl.h"



static GLfloat Xrot, Xstep;
static GLfloat Yrot, Ystep;
static GLfloat Zrot, Zstep;
static GLfloat Step = 3.0; ///1.0;
static GLfloat Scale = 1.0;



#define POINT_NUM       40  ////40 point per layer
#define LAYER_NUM       15  ////10 layers

typedef struct _GL_Point_Struct
{
    GLfloat x;
    GLfloat y;
    GLfloat z;
}GL_Point;



typedef struct _ONE_LAYER_POINT
{
    GL_Point points[POINT_NUM + 1];
    GLint    ValidPointNumber;
}Layer;


Layer glLayer[LAYER_NUM];

GL_Point testpoint[40]=
{
    {1,0,0},{1.1, 0.1, 0},{1.0, 0.2, 0},{1.2,0.3,0},{0.9,0.4,0},{0.85,0.6,0},{0.7,0.6,0},{0.6,0.5,0},{0.4,0.4,0},{0.2,1.1,0},
    {0,1,0},{-0.1,0.9,0},{-0.2,0.8,0},{-0.3,0.7,0},{-0.4,0.6,0},{-0.5,0.5,0},{-0.6,0.4,0},{-0.7,0.3,0},{-0.8,0.2,0},{-0.9,0.1,0},
    {-1,0,0},{-0.9,-0.1,0},{-0.8,-0.2,0},{-0.7,-0.3,0},{-0.6,-0.4,0},{-0.5,-0.5,0},{-0.4,-0.6,0},{-0.3,-0.7,0},{-0.2,-0.8,0},{-0.1,-0.9,0},
    {0,-1,0},{0.1,-0.9,0},{0.2,-0.8,0},{0.3,-0.7,0},{0.4,-0.6,0},{0.5,-0.5,0},{0.6,-0.4,0},{0.7,-0.3,0},{0.8,-0.2,0},{0.9,-0.1,0},
};

void InitPoint()
{
    unsigned int i,j;
    GLfloat zvalue;
    GLfloat x;
    GLfloat y;
    GLfloat z;

    for(i=0; i<LAYER_NUM; i++)
    {
        zvalue = i*0.05;

        for(j=0; j<POINT_NUM; j++)
        {
            x=glLayer[i].points[j].x = testpoint[j].x;
            y=glLayer[i].points[j].y = testpoint[j].y;
            z=glLayer[i].points[j].z = zvalue;
        }

        x=glLayer[i].points[POINT_NUM].x = glLayer[i].points[0].x;
        y=glLayer[i].points[POINT_NUM].y = glLayer[i].points[0].y;
        z=glLayer[i].points[POINT_NUM].z = glLayer[i].points[0].z;
    }
}



void setpoint(unsigned int layer, unsigned int number)
{
    glVertex3f(glLayer[layer].points[number].x,
               glLayer[layer].points[number].y,
               glLayer[layer].points[number].z);
}


void DrawLayer(GLint layer)
{
    unsigned int i;
    unsigned int validnum = glLayer[layer].ValidPointNumber;

    glBegin(GL_TRIANGLES);

    for(i=0; i<POINT_NUM; i++)
    {
        glVertex3f(0,
                   0,
                   glLayer[layer].points[i].z);
        setpoint(layer, i);
        setpoint(layer, i+1);
    }
    glEnd();
}


void DrawSide(GLint layerup, GLint layerdown)
{
    unsigned int i;

    glBegin(GL_TRIANGLES);

    for(i=0; i<POINT_NUM; i++)
    {
        setpoint(layerup, i);
        setpoint(layerdown, i);
        setpoint(layerdown, i+1);

        setpoint(layerup, i);
        setpoint(layerdown, i+1);
        setpoint(layerup, i+1);
    }
    glEnd();
}


unsigned int glValidLayCnt = 0;


static int drawfirsttime = 1;

int api_sgl(unsigned char* indata,
            unsigned char* outbuffer,
            unsigned int datalen,
            unsigned int width,
            unsigned int height
            )
{
    ctx = fbdev_glXCreateContext();
    fbdev_glXMakeCurrent(ctx, width, height, 16, outbuffer);

    glCullFace(GL_BACK);
    //glEnable( GL_CULL_FACE );
    glDisable(GL_DITHER);
    glShadeModel(GL_FLAT);
    //glEnable( GL_DEPTH_TEST );///

    Xrot = Zrot = 0.0;
    Yrot = 0.0;
    Xstep = Step;
    Ystep = Zstep = 0.0;

    if(drawfirsttime == 1)
    {
       drawfirsttime = 0;
       InitPoint();  ////get test data
    }

    /*
    else
    {
        printf("brfore select pointer\r\n");

        SelectPoint(indata, datalen);

        printf("after select pointer\r\n");
    }*/

    reshape(width, height);

    draw(indata, datalen);

    return 0;
}


/*
void redraw(void *indata, unsigned int datalen)
{
    unsigned int laycnt = 0;

    printf("brfore select pointer\r\n");
    laycnt = SelectPoint(indata, datalen);
    printf("after select pointer\r\n");

    if(laycnt == LAYER_NUM)
    {
        draw(indata, datalen);
    }
}
*/

#if 1

void reshape( int width, int height )
{
   glViewport(0, 0, (GLint)width, (GLint)height);

   glMatrixMode(GL_PROJECTION);
   glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

   glLoadIdentity();
   glFrustum( -1.0, 1.0, -1.0, 1.0, 5.0, 15.0 );
   glMatrixMode(GL_MODELVIEW);
}

unsigned char rotate=0;

void draw(void* indata, unsigned int datalen)
{
    GLint i=0;
    Scale = 1.0;  ///0.6;
    //把整个窗口清理为当前清理颜色：黑色,清理深度缓冲区
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

    glPushMatrix();

    glTranslatef(0.0, 0.0, -10.0);
    glScalef( Scale, Scale, Scale );

   /*
   GLfloat lightAmbient[4] = { 0.8, 0.8, 0.8, 1.0 };
   GLfloat lightDiffuse[4] = { 1.0, 1.0, 1.0, 1.0 };
   GLfloat lightPosition[4] = { -1.0, -1.0, -5.0, 1.0 };
   glLightfv( GL_LIGHT1, GL_AMBIENT, lightAmbient );
   glLightfv( GL_LIGHT1, GL_DIFFUSE, lightDiffuse );
   glLightfv( GL_LIGHT1, GL_POSITION, lightPosition );
   glEnable( GL_LIGHT1 );
   glEnable( GL_LIGHTING );
*/

    glRotatef(Xrot, 1.0, 0.0, 0.0 );
    glRotatef(Yrot, 0.0, 1.0, 0.0 );
    glRotatef(Zrot, 0.0, 0.0, 1.0 );


    if(1)
       glEnable(GL_DEPTH_TEST);//打开深度测试功能
    else
       glDisable(GL_DEPTH_TEST);//关闭深度测试功能
    //if(1)
    //    glEnable(GL_CULL_FACE);//打开不显示背面功能
    //else
       glDisable(GL_CULL_FACE);//关闭不显示背面功能
    //if(outLine)
    //    glPolygonMode(GL_BACK,GL_LINE);//多边形背部使用线条描框
    //else
    //   glPolygonMode(GL_BACK,GL_FILL);//多边形背部使用单色填充

    //进行平滑处理
    glEnable(GL_POINT_SMOOTH);
    glHint(GL_POINT_SMOOTH,GL_NICEST);
    glEnable(GL_LINE_SMOOTH);
    glHint(GL_LINE_SMOOTH,GL_NICEST);

/*
    GLfloat testcolor=0.2;

    for(i=0; i<LAYER_NUM-1; i++)
    {
        glColor3f(0.0, testcolor, 0.0);
        testcolor+=0.01;
        DrawLayer(i);
    }
*/

    GLfloat color=0.2;

    glColor3f(0.0, color, 0.0);
    DrawLayer(0);

    color+=0.01;
    glColor3f( 0.0, color, 0.0);
    DrawLayer(LAYER_NUM-1);


    for(i=0; i<LAYER_NUM-1; i++)
    {
        glColor3f(0.0, color, 0.0);
        color+=0.01;

        DrawSide(i, i+1);
    }

    glPopMatrix();
    glFlush();

    return 0;
}


void draw_event(void *indata, unsigned int datalen)
{

   Xrot += Xstep;
   Yrot += Ystep;
   Zrot += Zstep;

   if (Xrot>=360.0) {
      Xrot = Xstep = 0.0;
      Ystep = Step;
   }
   else if (Yrot>=360.0) {
      Yrot = Ystep = 0.0;
      Zstep = Step;
   }
   else if (Zrot>=360.0) {
      Zrot = Zstep = 0.0;
      Xstep = Step;
   }

   draw(indata, datalen);
}

#endif
