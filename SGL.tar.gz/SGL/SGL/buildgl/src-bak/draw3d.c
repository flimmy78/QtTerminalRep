#define _FB_TK_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <GL/gl.h>
#include <GL/glx.h>
#include "picotk.h"
#include <math.h>
#include <GL/internal/zgl.h>
#include "glx_impl.h"

static  FBDevGLXContext *ctx;

static GLfloat Xrot, Xstep;
static GLfloat Yrot, Ystep;
static GLfloat Zrot, Zstep;
static GLfloat Step = 1.0;
static GLfloat Scale = 1.0;
static GLuint Object;


typedef struct _KC_Data_Struct
{
	unsigned short Syn;			//同步头，0xFAAF
	unsigned short Serial;		//有效点数，1-2000 	
	short Pitch;		//旋转部分倾斜角，-180-180
	short Roll;			//旋转部分横滚角，-180-180
	short Heading;		//旋转部分方位角，0-359
	short Horizontal; 	//摆动部分水平角，向上扫描偏向+90度，向下偏向-90。
	unsigned short Data[2000];	//测距数据值，0x0DB8 = 3512/100 = 35.12米
}KC_Data;	

KC_Data  AngleData;

#define GL_PI 3.1415f



struct TinyFBDevGLXContext
{
    GLContext *gl_context; /* base class */
    void *screen;
    ZBuffer *zb;
    int line_length;
};


/* Create context */
FBDevGLXContext *fbdev_glXCreateContext()
{
    FBDevGLXContext *ctx;
    ctx = (FBDevGLXContext *) malloc(sizeof(FBDevGLXContext));

    if (ctx == NULL)
        return NULL;

    ctx->gl_context = NULL;
    ctx->screen = NULL;
    ctx->zb = NULL;
    ctx->line_length = 0;
    return ctx;
}

/*! Destroy context */
void fbdev_glXDestroyContext(FBDevGLXContext *ctx)
{
    if (ctx->gl_context != NULL)
    {
        glClose();
    }

    free (ctx);
}

/* resize the glx viewport */
static int glX_resize_viewport(GLContext *c,
                   int *xsize_ptr,
                   int *ysize_ptr)
{
    FBDevGLXContext *ctx;
    int xsize;
    int ysize;

    ctx = (FBDevGLXContext *) c->opaque;

    xsize = *xsize_ptr;
    ysize = *ysize_ptr;

    /* we ensure that xsize and ysize are multiples of 2 for the zbuffer.
       TODO: find a better solution */
    xsize &= ~3;
    ysize &= ~3;

    if (xsize == 0 || ysize == 0)
        return -1;

    *xsize_ptr = xsize;
    *ysize_ptr = ysize;

    /* resize the Z buffer */
    ZB_resize(c->zb, ctx->zb->pbuf, xsize, ysize);
    return 0;
}


/* we assume here that drawable is a buffer */
int fbdev_glXMakeCurrent(FBDevGLXContext *ctx,
                         unsigned int width,
                         unsigned int height,
                         unsigned char bitperpix,
                         unsigned char* outbuffer)
{
    int mode;
    int xsize;
    int ysize;
    int n_colors = 0;
    int bpp;
    ZBuffer *zb;
//	extern void*FrameBuffer;

    if (ctx->gl_context == NULL)
    {
      /* create the PicoGL context */
      xsize = width;
      ysize = height;
      bpp =   bitperpix;

      switch(bpp)
      {
        case 8:
            mode = ZB_MODE_INDEX;
        break;
        case 32:
            mode = ZB_MODE_RGBA;
        break;
        case 24:
            mode = ZB_MODE_RGB24;
        break;
        default:
            mode = ZB_MODE_5R6G5B;
        break;
      }
      zb = ZB_open (xsize, ysize, mode, n_colors,
            NULL, NULL, outbuffer);//NULL);

      if(zb == NULL)
        return 0;

      /* initialisation of the TinyGL interpreter */
      glInit( zb );
      ctx->gl_context = gl_get_context();
      ctx->gl_context->opaque = (void *) ctx;
      ctx->gl_context->gl_resize_viewport = glX_resize_viewport;

      /* set the viewport */
      /*  TIS: !!! HERE SHOULD BE -1 on both to force reshape  */
      /*  which is needed to make sure initial reshape is  */
      /*  called, otherwise it is not called..  */
      ctx->gl_context->viewport.xsize = xsize;
      ctx->gl_context->viewport.ysize = ysize;

      ctx->line_length =  width*2;//FixedInfo.line_length;
      glViewport( 0, 0, xsize, ysize );
    }

//	ctx->screen = FrameBuffer;

    ctx->zb=zb;
    return 1;
}


#if 0
/* Swap buffers */
void fbdev_glXSwapBuffers(FBDevGLXContext *ctx)
{
/*
       GLContext *gl_context;
       assert(ctx->gl_context);
 //    assert(ctx->screen);
       assert(ctx->zb);
       gl_context=gl_get_context();
       ctx=(FBDevGLXContext *)gl_context->opaque;
 //      ZB_copyFrameBuffer(ctx->zb, ctx->screen, ctx->line_length);
 */
}

/*
void tkSwapBuffers(void)
{
    fbdev_glXSwapBuffers(ctx);
}
*/
#endif




/*
 * Here on an unrecoverable error.
 *
 */
void errorcatcher()
{
}



int api_sgl(unsigned char* indata,
            unsigned char* outbuffer,
            unsigned int datalen,
            unsigned int width,
            unsigned int height
            )
{
    ctx = fbdev_glXCreateContext();
    fbdev_glXMakeCurrent(ctx, width, height, 16, outbuffer);

    glCullFace( GL_BACK );
    //glEnable( GL_CULL_FACE );
    glDisable( GL_DITHER );
    glShadeModel( GL_FLAT );
    //glEnable( GL_DEPTH_TEST );///

    Xrot = Zrot = 90.0;//0.0;
    Yrot = 135.0;//
    Xstep = Step;
    Ystep = Zstep = 0.0;

    reshape(width, height);

    draw_event(indata, datalen);

    return 0;
}


#if 1

void reshape( int width, int height )
{
   glViewport(0, 0, (GLint)width, (GLint)height);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glFrustum( -1.0, 1.0, -1.0, 1.0, 5.0, 15.0 );
   glMatrixMode(GL_MODELVIEW);
}


void draw(void* indata, unsigned int datalen)
{
    unsigned short* pData = (unsigned short*)indata;
    unsigned char* pSync = (unsigned short*)indata;
    unsigned short datasize;
    unsigned int  sync_count = 1;
    unsigned char jiaodu = 0;

    unsigned int totaldatalen = datalen;//sizeof(TestData);

    GLfloat x,y,z,angle;
    GLfloat lastX, lastY, lastZ;

    GLint i=0;

   glClear( GL_COLOR_BUFFER_BIT );

   glPushMatrix();

   glTranslatef( 0.0, 0.0, -10.0 );
   glScalef( Scale, Scale, Scale );
   if (Xstep)
   {
      glRotatef( Xrot, 1.0, 0.0, 0.0 );
   }
   else if (Ystep)
   {
      glRotatef( Yrot, 0.0, 1.0, 0.0 );
   }
   else
   {
      glRotatef( Zrot, 0.0, 0.0, 1.0 );
   }

///////////////////////////////////////////////////////////////////////////////////
	jiaodu = 0;
//    printf("totallen = %d\r\n", totaldatalen);

	while(totaldatalen > 0)
	{
		if( (*pSync==0xFA) && ( *(pSync+1)==0xAF) )
		{
            pData = pSync;
			memset(&AngleData, 0, sizeof(AngleData) );
			datasize = *(pData+1);
			memcpy(&AngleData, pData, 6 + 2*datasize);	
/*
			printf("=====New Sync %d: 0x%04X=====\r\n", sync_count++, AngleData.Syn);
			printf("AngleData.Serial = %d\r\n", AngleData.Serial);
			printf("AngleData.Pitch = %d\r\n", AngleData.Pitch/100);
			printf("AngleData.Roll = %d\r\n", AngleData.Roll/100);
			printf("AngleData.Heading = %d\r\n", AngleData.Heading/100);
			printf("AngleData.Horizontal = %d\r\n", AngleData.Horizontal/100);
			printf("\r\n");
*/
            glBegin(GL_LINES);

//////opengl draw 3D
			for(i=0; i<datasize; i++)
			{
                x = y = z = 0;

				angle = jiaodu*GL_PI/180.0f; 

                if(AngleData.Data[i] <1000)
                {
                    z = (AngleData.Data[i]/300.0f)*sin(angle);
                    x = (AngleData.Data[i]/300.0f)*cos(angle)*cos(2*GL_PI*i/datasize);
                    y = (AngleData.Data[i]/300.0f)*cos(angle)*sin(2*GL_PI*i/datasize);
                }
                ///////do last point///////

               // if(x<1 && y<1 && z<1)
				{
					glVertex3f(x, y, z);
				}

			}
			glEnd();
			jiaodu += 3.0f;
//////opengl draw 3D
		}	
		pSync ++;
		totaldatalen --;
	}
/////////////////////////////////////////////////////////////////////////////////////
   glPopMatrix();
   glFlush();
//   tkSwapBuffers();

    return 0;
}


void draw_event(void *indata, unsigned int datalen)
{
   Xrot += Xstep;
   Yrot += Ystep;
   Zrot += Zstep;

   if (Xrot>=360.0) {
      Xrot = Xstep = 0.0;
      Ystep = Step;
   }
   else if (Yrot>=360.0) {
      Yrot = Ystep = 0.0;
      Zstep = Step;
   }
   else if (Zrot>=360.0) {
      Zrot = Zstep = 0.0;
      Xstep = Step;
   }

   draw(indata, datalen);
}

#endif
