#include "fileviewer.h"



FileViewer::FileViewer( QWidget *parent, Qt::WindowFlags  f )
    : QDialog( parent, f )
{  
    lastvalidrow=0;
    currentrow=0;
    filenumber=0;

    setWindowTitle(tr("File Browser"));
    DirName = new QLabel();
    QFont font("WenQuanYi Micro Hei", 20, 55);    //( “Microsoft YaHei”, 10, 75);
    DirName->setFont(font);
    DirName->setText("存储文件列表");
	ListWidgetFile = new QListWidget();
    QVBoxLayout *vbLayout = new QVBoxLayout( this );      
    vbLayout->addWidget(DirName);
    vbLayout->addWidget(ListWidgetFile);

    ListStatus = new QLabel();
    QFont font1("WenQuanYi Micro Hei", 20, 55);    //( “Microsoft YaHei”, 10, 75);
    ListStatus->setFont(font1);
    vbLayout->addWidget(ListStatus);
    currentrow = 0;
}


FileViewer::~FileViewer()
{

}

int FileViewer::findcurrentItemPos()
{
    int y;
    int x = 100;
    int row;
    QListWidgetItem* pItem;

    for(y=0; y<576; y++)
    {
        pItem = ListWidgetFile->itemAt(x, y);
        row = ListWidgetFile->row(pItem);
        if(row == currentrow)
        {
            //printf("this y=%d, row=%d, current=%d\r\n", y, row, currentrow);
            return y;
        }
    }
}

void FileViewer::nextrow()
{
    if(currentrow < filenumber-1)
    {
        currentrow ++;
        ListWidgetFile->setCurrentRow(currentrow);
    }
    else
    {
        currentrow = 0;
        ListWidgetFile->setCurrentRow(currentrow);
    }
}

void FileViewer::prevrow()
{
    if(currentrow > 0)
    {
        currentrow --;
        ListWidgetFile->setCurrentRow(currentrow);
    }
    else
    {
        currentrow = filenumber-1;
        ListWidgetFile->setCurrentRow(currentrow);
    }
}

void FileViewer::showFileInfoList()
{
    unsigned int i;
    QString str;
    QStringList string;
    string << "*" ;

    QString root = "/home/root/media";
    QDir rootDir(root);

    QStringList filters;
    filters<<QString("*.AVI")<<QString("*.BMP");
    rootDir.setFilter(QDir::Files | QDir::NoSymLinks); //设置类型过滤器，只为文件格式
    rootDir.setNameFilters(filters);  //设置文件名称过滤器，只为filters格式（后缀为.jpeg等图片格式）

    QFileInfoList list = rootDir.entryInfoList(filters);

    QFont font("WenQuanYi Micro Hei", 20, 55);    //  ( “Microsoft YaHei”, 10, 75);

    ListWidgetFile->clear();
    filenumber = list.count();

    for(i=filenumber; i>0; i--)
    {
        QFileInfo tmpFileInfo = list.at(i-1);
        if(tmpFileInfo.isFile())
		{
            QIcon icon("/dm368/icon/file.png");
            QString fileName = tmpFileInfo.fileName();
            QListWidgetItem *pItem = new QListWidgetItem (icon, fileName);
            pItem->setSizeHint( QSize(60, 30) );  //每次改变Item的高度
            pItem->setFont(font);
            ListWidgetFile->addItem(pItem);
		}
    }
    str.sprintf("[%d条记录]", filenumber);
    ListStatus->setText(str);
}
