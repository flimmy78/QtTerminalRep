#include <QApplication>
#include "dialog.h"
#include <QWSServer>
#include <QTextCodec>
#include <stdlib.h>
#include "osdmanager.h"
#include <QStringList>
#include "qtinterface.h"
#include <QTextCodec>




int main(int argc, char *argv[])
{
    OSDManager osd;

    printf("\r\n[SGL-JPAD] Starting SGL-JPAD\r\n");
    printf("[SGL-JPAD] BUILD DATA:%s TIME:%s\r\n",__DATE__, __TIME__);

    if (!osd.setDisplayOutput(OSDManager::OUTPUT_COMPONENT))
    {
        qFatal("Could not set display output in interface\n");
        return -1;
    }
    if (!osd.setDisplayMode(OSDManager::MODE_720P_60))
    {
        qFatal("Could not set display mode in interface\n");
        return -1;
    }

 //   qDebug("Starting interface\n");

    QTextCodec *codec = QTextCodec::codecForName("UTF-8");//情况2
    QTextCodec::setCodecForTr(codec);
    QTextCodec::setCodecForLocale(codec);
    QTextCodec::setCodecForCStrings(codec);

    QApplication app(argc, argv);
    Dialog dlg;
    QWSServer::setBackground(QColor(0,0,0,0));
    QWSServer::setCursorVisible( false );

    dlg.showFullScreen();
 //   dlg.setGeometry(VIEW_XPOS, VIEW_YPOS, VIEW_WIDTH, VIEW_HEIGHT);


   // dlg.show();
/*
    dlg.osd.setBoxDimensions(0,0,720, 576);
    dlg.osd.hideOSD();
    //osd.showTransOSD();
    */
    return app.exec();
}
