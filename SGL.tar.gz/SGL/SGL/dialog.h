#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include "serial/com.h"
#include "receivethread.h"
#include <QtCore>
#include "messageserver.h"
#include "osdmanager.h"
#include "fileviewer.h"
#include <asm-generic/ioctl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <QImage>


#define FUN_VID_BYPASS   1        //use front bt656 signal as output video


#define WIDTH   720
#define HEIGHT  576

#define VIEW_XPOS   0
#define VIEW_YPOS   0
#define VIEW_WIDTH  1280
#define VIEW_HEIGHT 720

#define WIDTH_3DBOX   240
#define HEIGHT_3DBOX  200


#define LISBOX_WIDTH   720
#define LISBOX_HEIGHT  576
#define LISTBOX_XPOS   280
#define LISTBOX_YPOS   720

#define SHOWBOX_WIDTH  VIEW_WIDTH/2
#define SHOWBOX_HEIGHT VIEW_HEIGHT/2

#define OSD_XPOS   610
#define OSD_YPOS   30
#define OSD_WSIZE  65
#define OSD_HSIZE  20

#define FILE_IS_BMP 0x01
#define FILE_IS_AVI 0x02

/////status definition//////
#define STATUS_IDEL     0xff
#define STATUS_LIST     0x01
#define STATUS_PLAY     0x02
#define STATUS_PAUSE    0x03
#define STATUS_ENCODE   0x04
#define STATUS_SHOWBMP  0x05
#define STATUS_DIRLIST  0x06
#define STATUS_PLAYEND  0x07
#define STATUS_LOWPOWER 0x08

#define STATUS_MENU10   0x10
#define STATUS_MENU11   0x11
#define STATUS_MENU20   0x20
#define STATUS_MENU21   0x21

#define DEC_STATUS_PLAY  0x01
#define DEC_STATUS_PAUSE 0x02

///////new command definition/////////////
//#define CMDLEN         9 + 7
#define SHORT_CMDLEN   9
#define LONG_CMDLEN    9+7
#define RETCMDLEN      SHORT_CMDLEN


#define CMD_GET_PIC    0x3100
#define CMD_START_REC  0x3200
#define CMD_STOP_REC   0x3300
#define CMD_TRIG_PIC   0x3400
#define CMD_OPEN_DIR   0x3500
#define CMD_CLOSE_DIR  0x3600
#define CMD_POLL_VER   0x3A00
#define CMD_3D_CHANGE  0x3A00

#define CMD_FORMAT     0x3B00
#define CMD_LOWPWR     0x3C00
#define CMD_SETTIME    0x3E00

#define CMD_KEY_UP     0x3F01
#define CMD_KEY_DOWN   0x3F02
#define CMD_KEY_ENTER  0x3F05
#define CMD_KEY_EXIT   0x3F07


#define RET_START_OK      0x01
#define RET_CLOSE_DIR     0x02
#define RET_GET_TIME      0x03
#define RET_LOWPW_MODE    0x04
#define RET_READY_RESET   0x05
#define RET_TFCAP_LOW     0x06
#define RET_TFCAP_FULL    0x07
#define RET_NORMAL_MODE   0x08
#define RET_TFCAP_OK      0x09
#define RET_START_UPDATE  0x0A
#define RET_STOP_UPDATE   0x0B
#define RET_FORMAT_SD     0x0C

#define RET_CMD_PHOTO     0x31
#define RET_CMD_STARTREC  0x32
#define RET_CMD_STOPREC   0x33
#define RET_CMD_TRIGPIC   0x34
#define RET_CMD_OPENDIR   0x35




namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT
    
public:

    int width_3d;
    int height_3d;
    int bytePerLine_3d;

    unsigned char m_ScanData[1024*1024];
    unsigned int  m_ScanDataLen;
    unsigned char framedata[WIDTH_3DBOX*HEIGHT_3DBOX*2];

    QImage* image_draw3d;
    QPixmap pix;

    OSDManager osd;
    QLabel* ShowStatus;
    QMenu *popmenuseldel;
    QAction *palyAction;
    QAction *deletAction;

    QMenu *popmenusecond;
    QAction *nonedelAction;
    QAction *dodeletAction;

    unsigned char gl_filetype;
    unsigned char gpiobuf[5];

    unsigned char systemstatus;
    char cmdbuf[128];
    char videofilebuf[128];

    MessageServer msgServer;
    QTimer *timer;
    QTimer *timerflush;
    QString m_videoFile;
    FileViewer *fileview;
    int fd_com;
    int fd_gpio;
    ReceiveThread* recvthread;
    QImage image;

    int fd_watchdog;
    unsigned char gl_year;
    unsigned char gl_month;
    unsigned char gl_date;
    unsigned char gl_hour;
    unsigned char gl_minute;
    unsigned char gl_second;
    unsigned char gl_TFcardExist;
    unsigned int  gl_TFtotal;
    unsigned int  gl_TFleft;
    unsigned int  gl_TFcapalarm;
    struct stat gl_filestat;
    int popmenuX;
    int popmenuY;
    explicit Dialog(QWidget *parent = 0);
    ~Dialog();

  //  void SetFileInfoFromListRow();

    void SET_AUDIO_BYPASS();
    void SET_AUDIO_368OUT();
    void open_browser();
    void close_browser();
    int prepare_play(unsigned char mode);
    void FilePageDown();
    void FilePageUp();
    int SkipDownFile();
    int SkipUpFile();
    void GetFileInfo(char* filename);
    int SetGPIO(int value);
    int GetGPIO33(void);
    unsigned int getuartcmd(unsigned char* cmdbuf);
    void senduartcmd(unsigned char retcmdtype);
    int create_default_filename(char* filestr);
    int create_default_bmpfilename(char* filestr);
private:
    Ui::Dialog *ui;
private slots:
    void command_timerUpDate();
    void FlushUpDate();
};

#endif // DIALOG_H
