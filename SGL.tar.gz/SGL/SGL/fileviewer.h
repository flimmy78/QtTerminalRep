#ifndef FILEVIEWER_H
#define FILEVIEWER_H

#include <QtGui>

class FileViewer : public QDialog		// file information dialogs widget
{
    Q_OBJECT
public:
    FileViewer( QWidget *parent=0, Qt::WindowFlags  f=0 );
    ~FileViewer();
public:
    QLabel* DirName;
    QListWidget* ListWidgetFile;
    QLabel* ListStatus;
    unsigned int lastvalidrow;
    unsigned int currentrow;
    unsigned int filenumber;

public:
    int findcurrentItemPos();
    void showFileInfoList();
    void nextrow();
    void prevrow();
};


#endif // FILEVIEWER_H
