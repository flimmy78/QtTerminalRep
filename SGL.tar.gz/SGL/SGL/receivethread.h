#ifndef RECEIVETHREAD_H
#define RECEIVETHREAD_H

#include <QThread>
#include "fileviewer.h"

#define BUFFSIZE   40960

class ReceiveThread : public QThread
{
    Q_OBJECT
public:
    explicit ReceiveThread(QObject *parent = 0);
    void run();

    char commandbuffer[128];
    unsigned char status;
    FileViewer *fileview;
    QLabel *lable_file;
    unsigned char thread_interrupt;
    unsigned char thread_end;
};

#endif // RECEIVETHREAD_H
