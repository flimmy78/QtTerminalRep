#include "receivethread.h"
#include <QMessageBox>
#include <QDebug>
#include "dialog.h"

ReceiveThread::ReceiveThread(QObject *parent) :
    QThread(parent)
{

}

void ReceiveThread::run()
{
    //while(status == STATUS_PLAY)  //decode status is play
    {
        //thread_end = 0;
        system(commandbuffer);           //play file end or exit
        status = STATUS_PLAYEND;
        //thread_end = 1;
    }
}
