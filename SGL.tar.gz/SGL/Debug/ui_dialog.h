/********************************************************************************
** Form generated from reading UI file 'dialog.ui'
**
** Created by: Qt User Interface Compiler version 4.8.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_H
#define UI_DIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QLabel *label_showpic;
    QLabel *label_key1;
    QLabel *label_key2;
    QLabel *label_key3;
    QLabel *label_key4;
    QLabel *label_screen;
    QGroupBox *groupBox;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QGroupBox *groupBox_2;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_1;
    QLabel *label_dirlist;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QString::fromUtf8("Dialog"));
        Dialog->resize(640, 480);
        label_showpic = new QLabel(Dialog);
        label_showpic->setObjectName(QString::fromUtf8("label_showpic"));
        label_showpic->setGeometry(QRect(320, 4, 316, 236));
        label_showpic->setFrameShape(QFrame::Box);
        label_showpic->setLineWidth(2);
        label_key1 = new QLabel(Dialog);
        label_key1->setObjectName(QString::fromUtf8("label_key1"));
        label_key1->setGeometry(QRect(320, 455, 80, 25));
        QFont font;
        font.setFamily(QString::fromUtf8("WenQuanYi Micro Hei"));
        font.setPointSize(11);
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(50);
        label_key1->setFont(font);
        label_key1->setLayoutDirection(Qt::LeftToRight);
        label_key1->setFrameShape(QFrame::Box);
        label_key1->setAlignment(Qt::AlignCenter);
        label_key2 = new QLabel(Dialog);
        label_key2->setObjectName(QString::fromUtf8("label_key2"));
        label_key2->setGeometry(QRect(400, 455, 80, 25));
        QFont font1;
        font1.setFamily(QString::fromUtf8("WenQuanYi Micro Hei"));
        font1.setPointSize(11);
        label_key2->setFont(font1);
        label_key2->setFrameShape(QFrame::Box);
        label_key2->setAlignment(Qt::AlignCenter);
        label_key3 = new QLabel(Dialog);
        label_key3->setObjectName(QString::fromUtf8("label_key3"));
        label_key3->setGeometry(QRect(480, 455, 80, 25));
        label_key3->setFont(font1);
        label_key3->setFrameShape(QFrame::Box);
        label_key3->setAlignment(Qt::AlignCenter);
        label_key4 = new QLabel(Dialog);
        label_key4->setObjectName(QString::fromUtf8("label_key4"));
        label_key4->setGeometry(QRect(560, 455, 80, 25));
        label_key4->setFont(font1);
        label_key4->setFrameShape(QFrame::Box);
        label_key4->setAlignment(Qt::AlignCenter);
        label_screen = new QLabel(Dialog);
        label_screen->setObjectName(QString::fromUtf8("label_screen"));
        label_screen->setGeometry(QRect(0, 0, 640, 480));
        QFont font2;
        font2.setFamily(QString::fromUtf8("WenQuanYi Micro Hei"));
        label_screen->setFont(font2);
        groupBox = new QGroupBox(Dialog);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(320, 350, 316, 100));
        QFont font3;
        font3.setFamily(QString::fromUtf8("WenQuanYi Micro Hei"));
        font3.setPointSize(12);
        groupBox->setFont(font3);
        groupBox->setStyleSheet(QString::fromUtf8("QGroupBox{\n"
"	border-width:1px;\n"
"	border-style:solid;\n"
"	border-color:black;\n"
"	margin-top:0.5ex;\n"
"}\n"
"QGroupBox::title{\n"
"	subcontrol-origin:margin;\n"
"	subcontrol-position:top left;\n"
"    left:10px;\n"
"	margin-left:0px;\n"
"	padding:0 1px;\n"
"}"));
        groupBox->setFlat(false);
        label_4 = new QLabel(groupBox);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(10, 20, 300, 25));
        label_4->setFont(font3);
        label_5 = new QLabel(groupBox);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(10, 45, 300, 25));
        label_5->setFont(font3);
        label_6 = new QLabel(groupBox);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(10, 70, 300, 25));
        label_6->setFont(font3);
        label_4->raise();
        label_5->raise();
        label_6->raise();
        groupBox_2 = new QGroupBox(Dialog);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(320, 245, 316, 100));
        groupBox_2->setFont(font3);
        groupBox_2->setStyleSheet(QString::fromUtf8("QGroupBox{\n"
"	border-width:1px;\n"
"	border-style:solid;\n"
"	border-color:black;\n"
"	margin-top:0.5ex;\n"
"}\n"
"QGroupBox::title{\n"
"	subcontrol-origin:margin;\n"
"	subcontrol-position:top left;\n"
"    left:10px;\n"
"	margin-left:0px;\n"
"	padding:0 1px;\n"
"}"));
        groupBox_2->setFlat(false);
        label_2 = new QLabel(groupBox_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 45, 300, 25));
        QFont font4;
        font4.setFamily(QString::fromUtf8("WenQuanYi Micro Hei"));
        font4.setPointSize(12);
        font4.setBold(false);
        font4.setItalic(false);
        font4.setWeight(50);
        label_2->setFont(font4);
        label_3 = new QLabel(groupBox_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(10, 70, 300, 25));
        label_3->setFont(font4);
        label_1 = new QLabel(groupBox_2);
        label_1->setObjectName(QString::fromUtf8("label_1"));
        label_1->setGeometry(QRect(10, 20, 300, 25));
        label_1->setFont(font4);
        label_dirlist = new QLabel(Dialog);
        label_dirlist->setObjectName(QString::fromUtf8("label_dirlist"));
        label_dirlist->setGeometry(QRect(0, 0, 320, 480));

        retranslateUi(Dialog);

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QApplication::translate("Dialog", "Dialog", 0, QApplication::UnicodeUTF8));
        label_showpic->setText(QString());
        label_key1->setText(QApplication::translate("Dialog", "+:\344\270\212\347\277\273", 0, QApplication::UnicodeUTF8));
        label_key2->setText(QApplication::translate("Dialog", "-:\344\270\213\347\277\273", 0, QApplication::UnicodeUTF8));
        label_key3->setText(QApplication::translate("Dialog", "\346\213\215\345\275\225\351\224\256:\347\241\256\350\256\244", 0, QApplication::UnicodeUTF8));
        label_key4->setText(QApplication::translate("Dialog", "\350\217\234\345\215\225\351\224\256:\350\277\224\345\233\236", 0, QApplication::UnicodeUTF8));
        label_screen->setText(QString());
        groupBox->setTitle(QApplication::translate("Dialog", "\345\255\230\345\202\250\345\215\241\347\212\266\346\200\201", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("Dialog", "\345\255\230\345\202\250\347\251\272\351\227\264\346\200\273\345\205\261:", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("Dialog", "\345\255\230\345\202\250\347\251\272\351\227\264\344\275\277\347\224\250:", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("Dialog", "\345\255\230\345\202\250\347\251\272\351\227\264\345\211\251\344\275\231:", 0, QApplication::UnicodeUTF8));
        groupBox_2->setTitle(QApplication::translate("Dialog", " \346\226\207\344\273\266\344\277\241\346\201\257 ", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("Dialog", "\346\226\207\344\273\266\347\261\273\345\236\213:", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("Dialog", "\346\226\207\344\273\266\345\244\247\345\260\217:", 0, QApplication::UnicodeUTF8));
        label_1->setText(QApplication::translate("Dialog", "\346\226\207\344\273\266\346\227\245\346\234\237:", 0, QApplication::UnicodeUTF8));
        label_dirlist->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_H
