#ifndef GLX_H
#define GLX_H

#include <assert.h>
#include <errno.h>
#include <signal.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <linux/fb.h>
#include <linux/kd.h>
#include <linux/vt.h>
#include <GL/gl.h>
#include <math.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <GL/gl.h>

#ifdef __cplusplus
extern "C" {
#endif
typedef struct TinyFBDevGLXContext FBDevGLXContext;

static  FBDevGLXContext *ctx;

#define GL_PI 3.1415f

void errorcatcher()
{
}


struct TinyFBDevGLXContext
{
    GLContext *gl_context; /* base class */
    void *screen;
    ZBuffer *zb;
    int line_length;
};


/* Create context */
FBDevGLXContext *fbdev_glXCreateContext()
{
    FBDevGLXContext *ctx;
    ctx = (FBDevGLXContext *) malloc(sizeof(FBDevGLXContext));

    if (ctx == NULL)
        return NULL;

    ctx->gl_context = NULL;
    ctx->screen = NULL;
    ctx->zb = NULL;
    ctx->line_length = 0;
    return ctx;
}

/*! Destroy context */
void fbdev_glXDestroyContext(FBDevGLXContext *ctx)
{
    if (ctx->gl_context != NULL)
    {
        glClose();
    }

    free (ctx);
}

/* resize the glx viewport */
static int glX_resize_viewport(GLContext *c,int *xsize_ptr,int *ysize_ptr)
{
    FBDevGLXContext *ctx;
    int xsize;
    int ysize;

    ctx = (FBDevGLXContext *) c->opaque;

    xsize = *xsize_ptr;
    ysize = *ysize_ptr;

    /* we ensure that xsize and ysize are multiples of 2 for the zbuffer.
       TODO: find a better solution */
    xsize &= ~3;
    ysize &= ~3;

    if (xsize == 0 || ysize == 0)
        return -1;

    *xsize_ptr = xsize;
    *ysize_ptr = ysize;

    /* resize the Z buffer */
    ZB_resize(c->zb, ctx->zb->pbuf, xsize, ysize);
    return 0;
}

/* we assume here that drawable is a buffer */
int fbdev_glXMakeCurrent(FBDevGLXContext *ctx,unsigned int width,unsigned int height,
                         unsigned char bitperpix,unsigned char* outbuffer)
{
    int mode;
    int xsize;
    int ysize;
    int n_colors = 0;
    int bpp;
    ZBuffer *zb;
//	extern void*FrameBuffer;

    if (ctx->gl_context == NULL)
    {
      /* create the PicoGL context */
      xsize = width;
      ysize = height;
      bpp =   bitperpix;

      switch(bpp)
      {
        case 8:
            mode = ZB_MODE_INDEX;
        break;
        case 32:
            mode = ZB_MODE_RGBA;
        break;
        case 24:
            mode = ZB_MODE_RGB24;
        break;
        default:
            mode = ZB_MODE_5R6G5B;
        break;
      }
      zb = ZB_open (xsize, ysize, mode, n_colors, NULL, NULL, outbuffer);//NULL);

      if(zb == NULL)
        return 0;

      /* initialisation of the TinyGL interpreter */
      glInit( zb );
      ctx->gl_context = gl_get_context();
      ctx->gl_context->opaque = (void *) ctx;
      ctx->gl_context->gl_resize_viewport = glX_resize_viewport;

      /* set the viewport */
      /*  TIS: !!! HERE SHOULD BE -1 on both to force reshape  */
      /*  which is needed to make sure initial reshape is  */
      /*  called, otherwise it is not called..  */
      ctx->gl_context->viewport.xsize = xsize;
      ctx->gl_context->viewport.ysize = ysize;

      ctx->line_length =  width*2; //FixedInfo.line_length;
      glViewport( 0, 0, xsize, ysize );
    }

//	ctx->screen = FrameBuffer;
    ctx->zb=zb;
    return 1;
}



#ifdef __cplusplus
}
#endif

#endif
