#ifndef UPSTREAM_GLX_H
#define UPSTREAM_GLX_H

/* the build system will assign proper glx header from implementation */
//#include "glx_impl.h"
//GLX_IMPL_HEADER

#endif
